from keras.models import load_model
import numpy as np
import pickle


from flask import Flask, render_template, request
import numpy as np
import tensorflow as tf

app = Flask(__name__)

# Load the trained model
model = pickle.load(open("model2.pkl", "rb"))


@app.route('/')
def home():
    return render_template('front.html')


@app.route('/predict2', methods=['POST'])

def predict():
    # Get input values from form
    age = request.form['age']
    gender = request.form['gender']
    education = request.form['education_lv']
    Browsing_H = request.form['B_hist']
    purchase = request.form['purchase_freq']
    payment = request.form['payment']

    # Manual mappings (same as training)
    age_map = {"Teen": 1, "Young Adult": 2, "Middle Aged": 3, "Senior": 4}
    gender_map = {"M": 5, "F": 6, "Other": 7}
    edu_map = {"HS": 8, "Bachelor's": 9, "Master's": 10, "PhD": 11}
    browse_map = {"Electronics": 12, "Clothing": 13, "Books": 14, "Home Goods": 15}
    purchase_map = {"High": 16, "Medium": 17, "Low": 18}
    pay_map = {"Credit Card": 19, "Debit Card": 20, "Online Payment": 21}

    # Apply mappings
    try:
        age_val = age_map[age]
        gen_val = gender_map[gender]
        ed_val = edu_map[education]
        bh_val = browse_map[Browsing_H]
        pu_val = purchase_map[purchase]
        py_val = pay_map[payment]
    except KeyError as e:
        return f"Invalid input value: {e}", 400   

    # Create input array for prediction
    input_array = [[age_val, gen_val, ed_val, bh_val, pu_val, py_val]]

    # Make prediction using the loaded model
    prediction = model.predict(input_array)

    # Extract the predicted output value
    output = prediction[0]

    return render_template('front.html', prediction=output)


if __name__ == '__main__':
    app.run(debug=True)
